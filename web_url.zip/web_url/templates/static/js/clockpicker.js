'use strict';
$(document).ready(function () {

    $('.clockpicker').clockpicker();

    $('.clockpicker-autoclose').clockpicker({
        autoclose: true
    });

});
