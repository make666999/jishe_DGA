'use strict';
$(document).ready(function () {

    $(".tagsinput").tagsinput('items');

});
