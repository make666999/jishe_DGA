'use strict';
$(document).ready(function () {

    $('#datatable-example').DataTable({
        responsive: true
    });

});
